# Frozen #709 measurement evidence

This bundle contains counts-only metrics, selected non-secret environment values,
logs and the exact analysis/harness snapshots. It contains no fixture database,
private identity files or daemon binary. Absolute paths and PIDs in acquisition
metadata describe the original host; analysis only reads these bundled files.

From the repository root on Linux with Python 3:

    mkdir -p target/709-evidence-replay
    tar -xzf docs/goals/p0-2026-10-28-663-608-609-625/evidence/709-heap-soak-evidence.tar.gz -C target/709-evidence-replay
    cd target/709-evidence-replay
    python3 analyze.py heap-3600 > recomputed-default.json
    python3 analyze.py purge-3600 > recomputed-purge.json

Run from the extracted directory so the method imports the frozen harness.
The helper runs dense/sparse/missing-window and signed-residual self-checks.
Compare the outputs with each run's analysis.json. MANIFEST.json gives SHA-256
for every other member; all members are regular files beneath this directory.
http-without-transport.json records the separate live bootstrap observation.
purge-unmatched-peer is an intentionally stopped setup check, excluded from
the accepted sixty-minute comparisons; see its discard-reason.json.
