import importlib.util
import json
from pathlib import Path
import statistics
import sys

MIB = 1024**2


def windows(times, anon, heap, anchor, duration, width=600):
    result = []
    for number in range(int((duration - anchor) // width) + 1):
        start = anchor + number * width
        if start >= duration:
            break
        end = min(start + width, duration)
        indices = [i for i, t in enumerate(times) if start <= t < end]
        if not indices:
            continue
        a = statistics.median(anon[i] for i in indices)
        h = statistics.median(heap[i] for i in indices)
        gaps = [times[b] - times[a] for a, b in zip(indices, indices[1:])]
        max_gap = max(gaps, default=0)
        coverage = times[indices[0]] - start <= 10 and end - times[indices[-1]] <= 10 and max_gap <= 10
        result.append({
            "start_secs": start, "end_secs": end,
            "complete": start + width <= duration,
            "samples": len(indices), "anon_median_bytes": a,
            "cadence_coverage_valid": coverage, "max_sample_gap_secs": max_gap,
            "rust_requested_median_bytes": h,
            "rust_requested_min_bytes": min(heap[i] for i in indices),
            "rust_requested_max_bytes": max(heap[i] for i in indices),
            "requested_to_anon_median_ratio": h / a,
            "unclassified_anon_minus_requested_rust_bytes": a - h,
        })
    return result


def coverage_valid(rows, anchor, duration, width=600):
    full = [r for r in rows if r["complete"]]
    expected = max(0, int((duration - anchor) // width))
    return (expected > 0 and [r["start_secs"] for r in full] ==
            [anchor + i * width for i in range(expected)] and
            all(r["cadence_coverage_valid"] for r in full))


def self_test():
    rows = windows(list(range(0, 120, 10)), list(range(0, 120, 10)), [200] * 12, 0, 120, 60)
    assert [r["samples"] for r in rows] == [6, 6]
    assert [r["anon_median_bytes"] for r in rows] == [25, 85]
    assert rows[0]["unclassified_anon_minus_requested_rust_bytes"] == -175
    assert all(r["complete"] for r in rows)
    assert all(r["cadence_coverage_valid"] for r in rows)
    assert not windows([300], [1], [1], 0, 600)[0]["cadence_coverage_valid"]
    assert not windows(list(range(0, 110, 10)), [1] * 11, [2] * 11, 0, 110, 60)[-1]["complete"]
    assert [r["start_secs"] for r in windows([0, 10, 20, 30], [1]*4, [1]*4, 10, 40, 20)] == [10, 30]
    dense = list(range(0, 1800, 5))
    assert coverage_valid(windows(dense, [1]*len(dense), [1]*len(dense), 0, 1800), 0, 1800)
    missing = list(range(0, 600, 5)) + list(range(1200, 1800, 5))
    assert not coverage_valid(windows(missing, [1]*len(missing), [1]*len(missing), 0, 1800), 0, 1800)


def analyze(root):
    root = Path(root)
    samples = [json.loads(line) for line in (root / "samples.jsonl").read_text().splitlines()]
    assert [r["index"] for r in samples] == list(range(len(samples)))
    times = [r["monotonic"] - samples[0]["monotonic"] for r in samples]
    assert all(b > a for a, b in zip(times, times[1:]))
    anon = [r["process"]["anon_bytes"] for r in samples]
    heap = [r["metrics"]["providers"]["heap"]["rust_allocated_bytes"] for r in samples]
    assert all(isinstance(h, int) and h > 0 for h in heap)
    run = json.loads((root / "run.json").read_text()) if (root / "run.json").exists() else {}
    complete = run.get("completed", False)
    duration = run["measured_duration_secs"] if complete else times[-1]
    phases = [r["metrics"]["storage"]["maintenance"] for r in samples]
    passes = [min(p[name]["runs_total"] for name in ("expiry", "quota", "payload")) for p in phases]
    assert all(b >= a for a, b in zip(passes, passes[1:]))
    completions = [{"passes": passes[i], "first_observed_secs": times[i],
                    "anon_bytes": anon[i], "rust_requested_bytes": heap[i]}
                   for i in range(1, len(samples)) if passes[i] > passes[i-1]]
    anchor = next((times[i] for i, count in enumerate(passes) if count >= 2), None)
    post = windows(times, anon, heap, anchor, duration) if anchor is not None else []
    full = [r for r in post if r["complete"]]
    errors = sum(phases[-1][name]["errors_total"] for name in ("expiry", "quota", "payload"))
    covered = coverage_valid(post, anchor, duration) if anchor is not None else False
    full_duration = complete and run.get("duration_secs", 0) >= 3600 and duration >= 3600
    valid = full_duration and len(full) >= 2 and errors == 0 and covered
    anon_deltas = [b["anon_median_bytes"] - a["anon_median_bytes"] for a, b in zip(full, full[1:])]
    heap_deltas = [b["rust_requested_median_bytes"] - a["rust_requested_median_bytes"] for a, b in zip(full, full[1:])]
    peak = max(range(len(samples)), key=lambda i: anon[i])
    spec = importlib.util.spec_from_file_location("soak663", "tools/scripts/resource_soak_663.py")
    harness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)
    result = {
        "schema": "lxmf-rs-709-heap-soak-v1", "completed": complete,
        "measured_duration_secs": duration, "samples": len(samples),
        "observed_sample_span_secs": times[-1],
        "max_sample_gap_secs": max(b-a for a,b in zip(times,times[1:])),
        "anon_observed_min_bytes": min(anon), "anon_observed_max_bytes": max(anon),
        "rust_requested_observed_min_bytes": min(heap),
        "rust_requested_observed_max_bytes": max(heap),
        "anon_peak_sample": {"index": peak, "elapsed_secs": times[peak],
            "anon_bytes": anon[peak], "rust_requested_bytes": heap[peak],
            "persistence": samples[peak]["metrics"]["providers"]["announce_persistence"]},
        "sdk_event_log_depth_first": samples[0]["metrics"]["depth"]["sdk_event_log_depth"],
        "sdk_event_log_depth_last": samples[-1]["metrics"]["depth"]["sdk_event_log_depth"],
        "packet_hashes_first": samples[0]["metrics"]["providers"]["transport_tables"]["packet_cache_hashes"],
        "packet_hashes_last": samples[-1]["metrics"]["providers"]["transport_tables"]["packet_cache_hashes"],
        "first_minute": windows(times, anon, heap, 0, min(60, duration), 60)[0],
        "last_minute": windows(times, anon, heap, max(0, duration-60), duration, 60)[0],
        "maintenance_completions": completions,
        "second_completed_pass_first_observed_secs": anchor,
        "post_second_pass_windows": post,
        "adjacent_complete_window_anon_deltas_bytes": anon_deltas,
        "adjacent_complete_window_requested_deltas_bytes": heap_deltas,
        "window_coverage_valid": covered,
        "full_3600_second_duration_valid": full_duration,
        "expected_complete_windows": int((duration-anchor)//600) if anchor is not None else 0,
        "observed_complete_windows": len(full),
        "coverage_definition": "all expected complete windows present; 5s nominal cadence, first/last within 10s of edges and every internal gap <= 10s",
        "maintenance_errors_total": errors,
        "phase_count_assumption": "ingress profile drives announces and SDK polls only; phase runs are scheduled invocations, valid as completed successful passes only with zero phase errors",
        "anon_window_gate": bool(valid and all(d <= MIB for d in anon_deltas)),
        "requested_flat_window_gate": bool(valid and
            max(r["rust_requested_median_bytes"] for r in full) - min(r["rust_requested_median_bytes"] for r in full) <= MIB),
        "requested_flat_definition": "max minus min complete-window median <= 1 MiB; not proof of absence of leaks",
        "resident_owner_80_percent_gate": "unresolved: requested sizes and anon RSS are different measures; no SQLite allowance or residual is credited as an owner",
        "summary": harness.summarize_samples(samples, 5),
        "client": harness.summarize_client(harness.load_jsonl(root / "client.jsonl")),
        "last_maintenance": phases[-1],
        "last_persistence": samples[-1]["metrics"]["providers"]["announce_persistence"],
        "last_transport_tables": samples[-1]["metrics"]["providers"]["transport_tables"],
        "run": run,
    }
    return result


self_test()
if __name__ == "__main__" and len(sys.argv) > 1:
    print(json.dumps(analyze(sys.argv[1]), indent=2, sort_keys=True))
