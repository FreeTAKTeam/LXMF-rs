# Frozen #709 resident attribution evidence

This is a new tagged/instrumented diagnostic run. It does not retrospectively
attribute the earlier #710 untagged traces. Names can change VMA merging and
pauses change timing. Cap requests are separate from resident mapping ownership.

The bundle contains raw VMA/rollup captures, metrics/client traces, logs, selected
non-secret environment, build provenance, a real naming-syscall witness and frozen
analysis/harness/tests. It contains no database, private identity or executable.
Original absolute paths/PIDs are acquisition metadata, not required external files.

From a fresh checkout on Linux with Python 3:

    mkdir -p target/709-resident-replay
    tar -xzf docs/goals/p0-2026-10-28-663-608-609-625/evidence/709-resident-attribution.tar.gz -C target/709-resident-replay
    cd target/709-resident-replay
    python3 analyze.py ingress-3600 > recomputed.json
    python3 -m unittest discover -s tools/scripts -p 'test_resource_soak_663*.py'

Run from the extracted root so only frozen scripts are imported. Compare parsed
recomputed.json with ingress-3600/analysis.json. MANIFEST.json hashes every other
member. The resident verifier checks every capture, including pre-gate observations;
it never discards missing, invalid or low-ownership data. The closure_acceptance
field combines resident ownership with duration/cadence, RSS/requested stability,
SDK-poll and persistence/error checks. Raw names assign allocator-managed mappings,
not live objects, retention, a leak verdict or production qualification.

The new window analysis uses quiescent Anonymous totals. Requested gauges and
phase counters were fetched before freezing, so paired before-capture data are
explicitly separate. Legacy harness summary RSS uses the earlier unpaused read.
