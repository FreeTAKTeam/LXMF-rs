"""Frozen, prospective local screen for the one #709 pager-cache candidate."""
import hashlib
import json
import math
from pathlib import Path
import sys

PHASES = ("expiry", "quota", "payload")


def load_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def counter_trace_valid(values):
    return (bool(values) and all(type(value) is int and value >= 0 for value in values)
            and all(b >= a for a, b in zip(values, values[1:])))


def measurements(root):
    root = Path(root)
    result = json.loads((root / "analysis.json").read_text())
    rows = load_rows(root / "samples.jsonl")
    anchor = result["resident_memory"]["anchor_index"]
    events = [row["cgroup"]["memory_events"] for row in rows]
    counters = [[row["process"]["cpu_ticks"] for row in rows]]
    counters += [[row["process"]["io"][name] for row in rows] for name in ("rchar", "read_bytes")]
    counters += [[row[name] for row in events] for name in ("high", "max", "oom", "oom_kill", "oom_group_kill")]
    assert all(counter_trace_valid(values) for values in counters), "Invalid/regressing cumulative source counter"
    assert all(type(row[section][key]) is int and row[section][key] >= 0
               for row in rows for section, key in (("process", "swap_bytes"), ("cgroup", "memory_swap_current")))
    for name in PHASES:
        phases = [row["metrics"]["storage"]["maintenance"][name] for row in rows]
        assert counter_trace_valid([phase["runs_total"] for phase in phases])
        assert all(type(phase["last_duration_ns"]) is int and phase["last_duration_ns"] >= 0 for phase in phases)
    return {
        "cpu_percent_one_core": result["summary"]["cpu_percent_one_core"],
        "logical_read_bytes_per_sec": result["summary"]["rchar_per_sec"],
        "physical_read_bytes_per_sec": result["summary"]["read_bytes_per_sec"],
        "poll_window_p95_median_us": result["client"]["latency_p95_us_median"],
        "poll_window_p95_max_us": result["client"]["latency_p95_us_max"],
        "post_first_phase_max_ns": {
            name: max(row["metrics"]["storage"]["maintenance"][name]["last_duration_ns"]
                      for row in rows if row["metrics"]["storage"]["maintenance"][name]["runs_total"] >= 2)
            for name in PHASES},
        "memory_high_delta": events[-1]["high"] - events[0]["high"],
        "memory_high_post_anchor_delta": events[-1]["high"] - events[anchor]["high"],
        "max_pressure_events": {name: max(row[name] for row in events) for name in ("max", "oom", "oom_kill")},
        "max_process_swap_bytes": max(row["process"]["swap_bytes"] for row in rows),
        "max_cgroup_swap_bytes": max(row["cgroup"]["memory_swap_current"] for row in rows),
    }


def performance_limits(baseline):
    return {
        "cpu_percent_one_core": max(baseline["cpu_percent_one_core"] * 1.25,
                                     baseline["cpu_percent_one_core"] + 1),
        "logical_read_bytes_per_sec": baseline["logical_read_bytes_per_sec"] * 1.10,
        "poll_window_p95_median_us": max(2000, baseline["poll_window_p95_median_us"] * 1.25),
        "poll_window_p95_max_us": 100000,
        "post_first_phase_max_ns": {name: max(10000000, value * 1.25)
                                     for name, value in baseline["post_first_phase_max_ns"].items()},
        "memory_high_delta": baseline["memory_high_delta"],
        "memory_high_post_anchor_delta": baseline["memory_high_post_anchor_delta"],
        "release_max_duration_ns": 100000000,
        "release_max_lock_wait_ns": 100000000,
    }


def release_fields_valid(metrics):
    required = ("attempts_total", "runs_total", "errors_total", "duration_ns_total",
                "max_duration_ns", "lock_wait_ns_total", "max_lock_wait_ns")
    return all(type(metrics.get(key)) is int and metrics[key] >= 0 for key in required)


def release_valid(metrics, expected, limits):
    return (type(expected) is int and expected > 0 and release_fields_valid(metrics)
            and metrics["attempts_total"] == metrics["runs_total"] == expected
            and metrics["errors_total"] == 0
            and 0 < metrics["max_duration_ns"] <= metrics["duration_ns_total"] <= metrics["max_duration_ns"] * expected
            and metrics["max_lock_wait_ns"] <= metrics["lock_wait_ns_total"] <= metrics["max_lock_wait_ns"] * expected
            and (metrics["max_lock_wait_ns"] == 0) == (metrics["lock_wait_ns_total"] == 0)
            and metrics["lock_wait_ns_total"] <= metrics["duration_ns_total"]
            and metrics["max_lock_wait_ns"] <= metrics["max_duration_ns"]
            and metrics["max_duration_ns"] <= limits["release_max_duration_ns"]
            and metrics["max_lock_wait_ns"] <= limits["release_max_lock_wait_ns"])


def performance_checks(candidate, limits):
    scalar_keys = ("cpu_percent_one_core", "logical_read_bytes_per_sec", "physical_read_bytes_per_sec",
                   "poll_window_p95_median_us", "poll_window_p95_max_us", "memory_high_delta",
                   "memory_high_post_anchor_delta", "max_process_swap_bytes", "max_cgroup_swap_bytes")
    values = [candidate.get(key) for key in scalar_keys]
    values += [candidate.get("post_first_phase_max_ns", {}).get(name) for name in PHASES]
    values += [candidate.get("max_pressure_events", {}).get(name) for name in ("max", "oom", "oom_kill")]
    if not all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in values):
        return {"numeric_inputs_valid": False}
    result = {key: candidate[key] <= limits[key] for key in (
        "cpu_percent_one_core", "logical_read_bytes_per_sec", "poll_window_p95_median_us",
        "poll_window_p95_max_us", "memory_high_delta", "memory_high_post_anchor_delta")}
    result.update({"phase_" + name: candidate["post_first_phase_max_ns"][name] <= limit
                   for name, limit in limits["post_first_phase_max_ns"].items()})
    result["no_max_oom_or_swap"] = (
        all(value == 0 for value in candidate["max_pressure_events"].values())
        and candidate["max_process_swap_bytes"] == candidate["max_cgroup_swap_bytes"] == 0)
    return result


def compare(baseline_root, candidate_root):
    baseline_root, candidate_root = Path(baseline_root), Path(candidate_root)
    criteria = json.loads(Path(__file__).with_name("candidate-predeclared.json").read_text())
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == criteria["comparison_script_sha256"]
    assert hashlib.sha256(Path(__file__).with_name("analyze.py").read_bytes()).hexdigest() == criteria["analysis_script_sha256"]
    for name, digest in criteria["baseline_input_sha256"].items():
        assert hashlib.sha256((baseline_root / name).read_bytes()).hexdigest() == digest
    baseline = measurements(baseline_root)
    assert baseline == criteria["baseline"] and performance_limits(baseline) == criteria["limits"]
    import analyze
    analysis = analyze.analyze(candidate_root)
    assert analysis == json.loads((candidate_root / "analysis.json").read_text())
    candidate = measurements(candidate_root)
    phase_counts = [analysis["last_maintenance"][name]["runs_total"] for name in PHASES]
    release = analysis["last_maintenance"].get("sqlite_cache_release", {})
    release_rows = [row["metrics"]["storage"]["maintenance"].get("sqlite_cache_release", {})
                    for row in load_rows(candidate_root / "samples.jsonl")]
    trace_valid = all(release_fields_valid(row) and row["errors_total"] == 0 for row in release_rows)
    cumulative = ("attempts_total", "runs_total", "errors_total", "duration_ns_total",
                  "max_duration_ns", "lock_wait_ns_total", "max_lock_wait_ns")
    if trace_valid:
        trace_valid = all(b[key] >= a[key] for a, b in zip(release_rows, release_rows[1:]) for key in cumulative)
    release_checks = (trace_valid and all(type(count) is int and count > 0 for count in phase_counts)
                      and len(set(phase_counts)) == 1
                      and release_valid(release, min(phase_counts), criteria["limits"]))
    checks = performance_checks(candidate, criteria["limits"])
    return {"schema": "lxmf-rs-709-cache-candidate-v1", "baseline": baseline, "candidate": candidate,
            "limits": criteria["limits"], "original_closure_acceptance": analysis["closure_acceptance"],
            "release": release, "release_trace_valid": trace_valid,
            "release_calls_valid": release_checks, "performance_checks": checks,
            "shipping_acceptance": bool(analysis["closure_acceptance"] and release_checks and all(checks.values())),
            "meaning": "One prospective local intervention; no SQLite byte credit, no retrospective baseline attribution, no production SLO qualification."}


def self_test():
    limits = {"release_max_duration_ns": 100, "release_max_lock_wait_ns": 100}
    valid = {"attempts_total": 2, "runs_total": 2, "errors_total": 0,
             "duration_ns_total": 80, "max_duration_ns": 50,
             "lock_wait_ns_total": 5, "max_lock_wait_ns": 3}
    assert release_valid(valid, 2, limits)
    assert not release_valid({}, 2, limits)
    assert not release_valid(valid, 3, limits)
    for key, value in (("errors_total", 1), ("attempts_total", 3), ("runs_total", 1),
                       ("max_duration_ns", 101), ("max_lock_wait_ns", 101), ("errors_total", False),
                       ("max_duration_ns", 0), ("max_duration_ns", 81), ("max_duration_ns", 39),
                       ("max_lock_wait_ns", 50), ("max_lock_wait_ns", 0), ("lock_wait_ns_total", 81)):
        assert not release_valid({**valid, key: value}, 2, limits)
    assert counter_trace_valid([0, 0, 2])
    for trace in ([], [0, -1], [2, 1], [False, 1], [0, float("nan")], [0, float("inf")]):
        assert not counter_trace_valid(trace)
    baseline = {"cpu_percent_one_core": 4, "logical_read_bytes_per_sec": 100, "physical_read_bytes_per_sec": 0,
                "poll_window_p95_median_us": 700, "poll_window_p95_max_us": 1000,
                "post_first_phase_max_ns": dict.fromkeys(PHASES, 1000000),
                "memory_high_delta": 444, "memory_high_post_anchor_delta": 12,
                "max_pressure_events": dict.fromkeys(("max", "oom", "oom_kill"), 0),
                "max_process_swap_bytes": 0, "max_cgroup_swap_bytes": 0}
    bounds = performance_limits(baseline)
    assert all(performance_checks(baseline, bounds).values())
    for key, value in baseline.items():
        for invalid in (False, -1, float("nan"), float("inf"), None):
            if isinstance(value, dict):
                for nested in value:
                    assert not all(performance_checks({**baseline, key: {**value, nested: invalid}}, bounds).values())
            else:
                assert not all(performance_checks({**baseline, key: invalid}, bounds).values())
    for key in ("cpu_percent_one_core", "logical_read_bytes_per_sec", "poll_window_p95_median_us",
                "poll_window_p95_max_us", "memory_high_delta", "memory_high_post_anchor_delta"):
        assert not all(performance_checks({**baseline, key: bounds[key] + 1}, bounds).values())
    assert not all(performance_checks({**baseline, "max_process_swap_bytes": 1}, bounds).values())
    assert not all(performance_checks({**baseline, "post_first_phase_max_ns": dict.fromkeys(PHASES, 10000001)}, bounds).values())


self_test()
if __name__ == "__main__" and len(sys.argv) == 3:
    print(json.dumps(compare(sys.argv[1], sys.argv[2]), indent=2, sort_keys=True))
