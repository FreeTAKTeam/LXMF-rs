# User-stopped #709 candidate and prepared Linux field-test release

The user canceled synthetic one-hour validation and asked for a real Linux test
release. Do not restart the synthetic soak. All four attempts have completed=false:
one acquired 10 captures over46.164s; three stopped before readiness. None reached
periodic maintenance or a cache-release call. Initial signal-source speculation
was corrected when the side conversation's confirmed human stop instruction was
relayed. These are cancellations, not policy failures or passing acceptance.

The full tagged baseline remains separately committed in
709-resident-attribution.tar.gz (SHA256
8f7c7cc289e0602b5d8f774fa8742f7c2ce4becee45fb9fb1f1ccd9c2664fd17).
It clears resident attribution and fails RSS stability. #709 and #663 stay open.
The candidate binary/source/criteria are frozen at132c692e; performance and RSS
remain unverified. The draft Linux x86-64 release packages the identical static
musl binary, with explicit experimental SQLite policy and VMA-naming limitations.

MANIFEST.json hashes every other member. No private identity, database or binary
is included. Absolute paths and PIDs are historical acquisition metadata. To
replay the10 canceled raw captures from a fresh extraction on Linux/Python3:

    PYTHONPATH=tools/scripts python3 -c "from pathlib import Path; from resource_soak_663_resident import verify_resident_run; print(verify_resident_run(Path('attempt-1-46s')))"
    python3 -m unittest discover -s tools/scripts -p 'test_resource_soak_663*.py'

The resident result has no second-pass anchor and cannot pass acceptance. Do not
run analyze/compare as if any canceled attempt were a completed3600s trial.
Standalone/package startup probes test only startup, not normal traffic or load.
