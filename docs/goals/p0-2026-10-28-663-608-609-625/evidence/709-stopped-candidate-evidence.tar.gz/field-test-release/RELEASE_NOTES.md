Linux x86-64 daemon-only **experimental test candidate** from immutable source [`132c692e80330bf0bf9fd75ae93607f0b1ab552d`](https://github.com/FreeTAKTeam/LXMF-rs/commit/132c692e80330bf0bf9fd75ae93607f0b1ab552d), PR [#711](https://github.com/FreeTAKTeam/LXMF-rs/pull/711). The daemon reports version 0.16.0. This is a draft testing release, not a stable-release promotion.

The archive includes `bin/reticulumd`, `BUILDINFO.json`, README deployment/rollback instructions and the license. It is statically linked with musl for Linux x86-64; ARM64 is not included. Built locally with Rust 1.99.1 and locked dependencies, default features including ZeroMQ RPC; no hosted build attestation.

### Changes for field testing

- Heap requested-byte gauge and earlier #663 resource/readiness/maintenance fixes.
- Experimental safe SQLite pager-cache release after successful periodic propagation maintenance, with attempt/completion/error/duration/lock-wait counters. It may release unpinned pages across the bundled SQLite shared pager group; it is not writer-only ownership or a resident-byte measurement.
- Existing mimalloc Linux VMA-name hook enabled through the documented two C macros for resident mapping diagnostics. No application unsafe or native allocator override.

### Validation and known limits

The 60-minute candidate soak was explicitly stopped at the user's request so testing can move to a real Linux system. The interrupted trial is not acceptance evidence. The completed tagged baseline attributed at least 91.203% in all 593 post-anchor captures, but its first adjacent 10-minute medians grew by 2.328125 MiB against the 1 MiB limit. **RSS stability and prospective candidate performance remain unverified; #709 and #663 stay open.** Source PR #711 is unmerged at preparation.

Source RPC/daemon suites, focused storage/timer regressions, formatting, Clippy and architecture checks passed before packaging. Exact packaged bytes passed `--help`, `/healthz`, `/readyz`, a positive heap gauge, zero release calls with propagation disabled, clean SIGINT shutdown and Unix-socket cleanup. At preparation, 27 hosted checks passed; pending: none. The intentional HIL publish skip is not a failed check. The full stable-release certification workflow was not rerun.

### Install

Download the tar.gz and `SHA256SUMS` together and run `sha256sum -c SHA256SUMS`, then extract the archive. Stop the service that owns the daemon before replacing its executable, back up its data consistently, keep the old executable for rollback, and preserve the existing identity/config/database, command arguments and limits. The README describes optional process-local `MIMALLOC_PURGE_DELAY=0` and `MIMALLOC_ARENA_EAGER_COMMIT=0` settings used in the local experiment; these are not established production defaults. No fixed one-hour soak runs on installation.

Use existing authenticated/private RPC endpoints and normal traffic to observe memory/pressure, maintenance counters, poll latency and delivery. See the [deployment guide](https://github.com/FreeTAKTeam/LXMF-rs/blob/132c692e80330bf0bf9fd75ae93607f0b1ab552d/docs/runbooks/reticulumd-operational-deployment.md). This daemon-only testing release publishes no crates, container or other-platform binaries.

Binary SHA-256: `b6d622812040d66f19b82e0883f47693cdfab3a1649acd48a3096b201205828a`.
