# reticulumd 0.16.0 Linux x86-64 test candidate

Release: `reticulumd-test-0.16.0-linux-132c692e.1`
Source: `132c692e80330bf0bf9fd75ae93607f0b1ab552d` (PR #711, not merged at packaging).
Binary SHA-256: `b6d622812040d66f19b82e0883f47693cdfab3a1649acd48a3096b201205828a`.

This static-musl build is for Linux x86-64 real-system testing. ARM64 is not
included. It contains the heap-request gauge, earlier #663 fixes and the new
experimental SQLite pager-cache release after successful periodic propagation
maintenance. Default daemon features include ZeroMQ RPC. The existing mimalloc
Linux VMA-name hook is enabled for diagnostic resident mapping measurements.

The candidate's one-hour local soak was stopped at the user's request. It has
not passed the RSS stability or prospective performance screens. The completed
baseline cleared >=80% resident mapping attribution but grew 2.328125 MiB between
its first two post-anchor 10-minute medians. #709 and #663 remain open. No stable
release, crate publication, container, service configuration or memory limit is
changed by this package.

## Verify and install

Download the archive and SHA256SUMS into one directory, then run:

```sh
sha256sum -c SHA256SUMS
tar -xzf reticulumd_0.16.0-linux-132c692e.1_x86_64.tar.gz
./reticulumd_0.16.0-linux-132c692e.1_x86_64/bin/reticulumd --help
```

Stop the service that owns your existing daemon before replacing its executable.
Keep the old executable for rollback and back up the existing identity, config,
database and any active WAL consistently while the service is stopped. Replace
only the executable, preserving your existing arguments, service limits and data
paths. This archive does not include identities, databases or configuration.

For testing the same allocator settings used in the local experiment, set these
environment variables in the daemon's existing service configuration:

```sh
MIMALLOC_PURGE_DELAY=0
MIMALLOC_ARENA_EAGER_COMMIT=0
```

Those values are optional process-local experimental settings, not established
production defaults. The pager-cache release runs when propagation maintenance
is enabled through your existing configuration. Do not enable propagation merely
to install the binary. Remove only test-added settings when rolling back.

Use your existing private RPC endpoint to collect `/healthz`, `/readyz` and
`/metrics` during normal traffic. Relevant metrics include
`providers.heap.rust_allocated_bytes`, `memory.process.anon_bytes`,
`storage.maintenance.sqlite_cache_release`, the three original maintenance phases,
and persistence counters. Requested bytes, SQLite cache estimates and named-map
resident bytes are different measurements; do not subtract them to claim a leak
or allocator ownership. Record process/cgroup memory, pressure, errors and poll
latency alongside normal delivery behavior. No fixed one-hour local soak is run
by installation. Keep RPC protected using your existing authentication/bindings.

Deployment and rollback guidance:
https://github.com/FreeTAKTeam/LXMF-rs/blob/132c692e80330bf0bf9fd75ae93607f0b1ab552d/docs/runbooks/reticulumd-operational-deployment.md

Validation: source RPC/daemon suites, focused timer/storage regressions, Clippy
and architecture gates passed before packaging. The built daemon passed standalone
readiness, a positive heap gauge, zero release calls with propagation disabled,
and clean SIGINT shutdown. BUILDINFO.json binds the executable to its source and
build flags. Real Linux deployment/load and long-run resource behavior remain
unverified. See the release notes for the hosted-check status at preparation.
